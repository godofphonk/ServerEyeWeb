namespace ServerEye.Core.Enums;

public enum UserStatus
{
    None,
    Active = 1,
    Inactive = 2,
}
