using Microsoft.AspNetCore.Mvc;

namespace ServerEye.API.Controllers.Debug;

[ApiController]
[Route("api/debug")]
public class DebugController : ControllerBase
{
    [HttpGet("telegram-oauth-test")]
    public IActionResult TestTelegramOAuth()
    {
        // Simulate Telegram OAuth data structure
        var telegramData = new
        {
            id = 1805441944,
            first_name = "Test",
            last_name = "User",
            username = "test_user",
            photo_url = "https://t.me/i/userpic/320/test_user.jpg"
        };

        return Ok(new
        {
            message = "Test Telegram OAuth data structure",
            data = telegramData
        });
    }

    [HttpPost("telegram-oauth-data")]
    public IActionResult LogTelegramOAuthData([FromBody] object data)
    {
        // Log actual Telegram OAuth data
        return Ok(new
        {
            message = "Telegram OAuth data received",
            data,
            dataType = data.GetType().Name
        });
    }
}
