namespace ServerEye.Core.Enums;

public enum SubscriptionPlan
{
    Free = 0,
    Pro = 1,
    Enterprise = 2
}
